﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project_2
{
    public partial class Form4 : Form
    {
        Image[] images = new Image[4];
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void btn_Back1_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            images[0] = Image.FromFile("G:\\Visual Studio 2022\\Project 2\\Project 2/Arizona Cardinals.jpg");
            images[1] = Image.FromFile("G:\\Visual Studio 2022\\Project 2\\Project 2/Atlanta Falcons.jpg");
            images[2] = Image.FromFile("G:\\Visual Studio 2022\\Project 2\\Project 2/New Orleans Saints.jpg");
            images[3] = Image.FromFile("G:\\Visual Studio 2022\\Project 2\\Project 2/Tampa Bay Buccaneers.jpg");

            void display(int i)
            {
                for (int k = 0; k < i; k++)
                {
                    pictureBox1.Image = images[k];
                    MessageBox.Show("image # " + (k + 1));
                }
            }
            display(4);
        }
    }
}
