﻿namespace Project_2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            button1 = new Button();
            btn_Back1 = new Button();
            groupBox2 = new GroupBox();
            btn_doloop = new Button();
            btn_While = new Button();
            btn_4loop = new Button();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            groupBox3 = new GroupBox();
            btn_Dialog = new Button();
            btn_R2F = new Button();
            btn_W2F = new Button();
            textBox4 = new TextBox();
            label3 = new Label();
            openFileDialog1 = new OpenFileDialog();
            groupBox4 = new GroupBox();
            btn_Sum = new Button();
            btn_Average = new Button();
            txt_Function = new TextBox();
            btn_Function = new Button();
            btn_Next = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button1);
            groupBox1.Location = new Point(26, 23);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(200, 237);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(34, 121);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(34, 46);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 0;
            button1.Text = "Check Int";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btn_Back1
            // 
            btn_Back1.Location = new Point(26, 414);
            btn_Back1.Name = "btn_Back1";
            btn_Back1.Size = new Size(75, 23);
            btn_Back1.TabIndex = 1;
            btn_Back1.Text = "Back";
            btn_Back1.UseVisualStyleBackColor = true;
            btn_Back1.Click += btn_Back1_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btn_doloop);
            groupBox2.Controls.Add(btn_While);
            groupBox2.Controls.Add(btn_4loop);
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(textBox2);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(232, 23);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(200, 237);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "groupBox2";
            // 
            // btn_doloop
            // 
            btn_doloop.Location = new Point(22, 179);
            btn_doloop.Name = "btn_doloop";
            btn_doloop.Size = new Size(75, 23);
            btn_doloop.TabIndex = 6;
            btn_doloop.Text = "Do Loop";
            btn_doloop.UseVisualStyleBackColor = true;
            // 
            // btn_While
            // 
            btn_While.Location = new Point(22, 150);
            btn_While.Name = "btn_While";
            btn_While.Size = new Size(75, 23);
            btn_While.TabIndex = 5;
            btn_While.Text = "While Loop";
            btn_While.UseVisualStyleBackColor = true;
            // 
            // btn_4loop
            // 
            btn_4loop.Location = new Point(22, 121);
            btn_4loop.Name = "btn_4loop";
            btn_4loop.Size = new Size(75, 23);
            btn_4loop.TabIndex = 4;
            btn_4loop.Text = "For Loop";
            btn_4loop.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(22, 92);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(22, 48);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 74);
            label2.Name = "label2";
            label2.Size = new Size(59, 15);
            label2.TabIndex = 1;
            label2.Text = "Last Value";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 30);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 0;
            label1.Text = "First Value";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btn_Dialog);
            groupBox3.Controls.Add(btn_R2F);
            groupBox3.Controls.Add(btn_W2F);
            groupBox3.Controls.Add(textBox4);
            groupBox3.Controls.Add(label3);
            groupBox3.Location = new Point(26, 266);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(612, 142);
            groupBox3.TabIndex = 3;
            groupBox3.TabStop = false;
            groupBox3.Text = "groupBox3";
            // 
            // btn_Dialog
            // 
            btn_Dialog.Location = new Point(447, 74);
            btn_Dialog.Name = "btn_Dialog";
            btn_Dialog.Size = new Size(159, 39);
            btn_Dialog.TabIndex = 4;
            btn_Dialog.TabStop = false;
            btn_Dialog.Text = "Used file dialog";
            btn_Dialog.UseVisualStyleBackColor = true;
            btn_Dialog.Click += btn_Dialog_Click;
            // 
            // btn_R2F
            // 
            btn_R2F.Location = new Point(228, 74);
            btn_R2F.Name = "btn_R2F";
            btn_R2F.Size = new Size(159, 39);
            btn_R2F.TabIndex = 3;
            btn_R2F.TabStop = false;
            btn_R2F.Text = "Read 2 File";
            btn_R2F.UseVisualStyleBackColor = true;
            btn_R2F.Click += btn_R2F_Click;
            // 
            // btn_W2F
            // 
            btn_W2F.Location = new Point(20, 74);
            btn_W2F.Name = "btn_W2F";
            btn_W2F.Size = new Size(159, 39);
            btn_W2F.TabIndex = 2;
            btn_W2F.Text = "Write 2 File";
            btn_W2F.UseVisualStyleBackColor = true;
            btn_W2F.Click += btn_W2F_Click;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(130, 18);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(476, 23);
            textBox4.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 26);
            label3.Name = "label3";
            label3.Size = new Size(104, 15);
            label3.TabIndex = 0;
            label3.Text = "Text to write to file";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(btn_Sum);
            groupBox4.Controls.Add(btn_Average);
            groupBox4.Controls.Add(txt_Function);
            groupBox4.Controls.Add(btn_Function);
            groupBox4.Location = new Point(438, 23);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(200, 237);
            groupBox4.TabIndex = 4;
            groupBox4.TabStop = false;
            groupBox4.Text = "groupBox4";
            // 
            // btn_Sum
            // 
            btn_Sum.Location = new Point(35, 179);
            btn_Sum.Name = "btn_Sum";
            btn_Sum.Size = new Size(133, 23);
            btn_Sum.TabIndex = 3;
            btn_Sum.Text = "Sum";
            btn_Sum.UseVisualStyleBackColor = true;
            btn_Sum.Click += btn_Sum_Click;
            // 
            // btn_Average
            // 
            btn_Average.Location = new Point(35, 150);
            btn_Average.Name = "btn_Average";
            btn_Average.Size = new Size(133, 23);
            btn_Average.TabIndex = 2;
            btn_Average.Text = "Average";
            btn_Average.UseVisualStyleBackColor = true;
            btn_Average.Click += btn_Average_Click;
            // 
            // txt_Function
            // 
            txt_Function.Location = new Point(35, 92);
            txt_Function.Name = "txt_Function";
            txt_Function.Size = new Size(133, 23);
            txt_Function.TabIndex = 1;
            // 
            // btn_Function
            // 
            btn_Function.Location = new Point(35, 48);
            btn_Function.Name = "btn_Function";
            btn_Function.Size = new Size(133, 23);
            btn_Function.TabIndex = 0;
            btn_Function.Text = "Call a Function";
            btn_Function.UseVisualStyleBackColor = true;
            btn_Function.Click += btn_Function_Click;
            // 
            // btn_Next
            // 
            btn_Next.Location = new Point(563, 414);
            btn_Next.Name = "btn_Next";
            btn_Next.Size = new Size(75, 23);
            btn_Next.TabIndex = 5;
            btn_Next.Text = "Next";
            btn_Next.UseVisualStyleBackColor = true;
            btn_Next.Click += btn_Next_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(667, 442);
            Controls.Add(btn_Next);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(btn_Back1);
            Controls.Add(groupBox1);
            Name = "Form3";
            Text = "Form3";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox1;
        private Button button1;
        private Button btn_Back1;
        private GroupBox groupBox2;
        private Button btn_doloop;
        private Button btn_While;
        private Button btn_4loop;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label2;
        private Label label1;
        private GroupBox groupBox3;
        private Button btn_R2F;
        private Button btn_W2F;
        private TextBox textBox4;
        private Label label3;
        private Button btn_Dialog;
        private OpenFileDialog openFileDialog1;
        private GroupBox groupBox4;
        private Button btn_Function;
        private TextBox txt_Function;
        private Button btn_Next;
        private Button btn_Sum;
        private Button btn_Average;
    }
}