﻿namespace Project_2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ldl_user = new Label();
            lbl_pass = new Label();
            tb_user = new TextBox();
            tb_pass = new TextBox();
            btn_login = new Button();
            groupBox1 = new GroupBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // ldl_user
            // 
            ldl_user.AutoSize = true;
            ldl_user.Location = new Point(24, 62);
            ldl_user.Name = "ldl_user";
            ldl_user.Size = new Size(60, 15);
            ldl_user.TabIndex = 0;
            ldl_user.Text = "Username";
            // 
            // lbl_pass
            // 
            lbl_pass.AutoSize = true;
            lbl_pass.Location = new Point(24, 100);
            lbl_pass.Name = "lbl_pass";
            lbl_pass.Size = new Size(57, 15);
            lbl_pass.TabIndex = 1;
            lbl_pass.Text = "Password";
            // 
            // tb_user
            // 
            tb_user.Location = new Point(116, 57);
            tb_user.Margin = new Padding(3, 2, 3, 2);
            tb_user.Name = "tb_user";
            tb_user.Size = new Size(110, 23);
            tb_user.TabIndex = 2;
            // 
            // tb_pass
            // 
            tb_pass.Location = new Point(116, 95);
            tb_pass.Margin = new Padding(3, 2, 3, 2);
            tb_pass.Name = "tb_pass";
            tb_pass.Size = new Size(110, 23);
            tb_pass.TabIndex = 3;
            // 
            // btn_login
            // 
            btn_login.Location = new Point(116, 148);
            btn_login.Margin = new Padding(3, 2, 3, 2);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(109, 22);
            btn_login.TabIndex = 4;
            btn_login.Text = "Login";
            btn_login.UseVisualStyleBackColor = true;
            btn_login.Click += btn_login_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(ldl_user);
            groupBox1.Controls.Add(btn_login);
            groupBox1.Controls.Add(lbl_pass);
            groupBox1.Controls.Add(tb_pass);
            groupBox1.Controls.Add(tb_user);
            groupBox1.Location = new Point(37, 9);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(262, 188);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(334, 215);
            Controls.Add(groupBox1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form2";
            Text = "Form2";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label ldl_user;
        private Label lbl_pass;
        private TextBox tb_user;
        private TextBox tb_pass;
        private Button btn_login;
        private GroupBox groupBox1;
    }
}