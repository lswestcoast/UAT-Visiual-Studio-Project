﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_6._1_Final_Project_v3
{
    public partial class Form2 : Form
    {
        interface IDrawing
        {
            void render();
        }

        class tablet : IDrawing
        {
            public void render()
            {
                MessageBox.Show("Render on a Ipad");
            }
        }

        class android : IDrawing
        {

            public void render()
            {
                MessageBox.Show("Render on an Android");
            }
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void lbl_Back_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tablet myTablet = new tablet();
            myTablet.render();

            android myAndroid = new android();
            myAndroid.render();
        }
    }
}
