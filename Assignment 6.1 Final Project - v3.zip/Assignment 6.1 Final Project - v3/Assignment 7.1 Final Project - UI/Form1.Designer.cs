﻿namespace Assignment_6._1_Final_Project_v3
{
    partial class Form1
    {
        /// <summary
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Fname = new System.Windows.Forms.Label();
            this.lbl_Lname = new System.Windows.Forms.Label();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.lbl_Hourwage = new System.Windows.Forms.Label();
            this.btn_Staff = new System.Windows.Forms.Button();
            this.btn_Ft = new System.Windows.Forms.Button();
            this.btn_Pt = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lbl_Next = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Fname
            // 
            this.lbl_Fname.AutoSize = true;
            this.lbl_Fname.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fname.Location = new System.Drawing.Point(54, 46);
            this.lbl_Fname.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_Fname.Name = "lbl_Fname";
            this.lbl_Fname.Size = new System.Drawing.Size(92, 21);
            this.lbl_Fname.TabIndex = 0;
            this.lbl_Fname.Text = "First Name";
            // 
            // lbl_Lname
            // 
            this.lbl_Lname.AutoSize = true;
            this.lbl_Lname.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lname.Location = new System.Drawing.Point(374, 46);
            this.lbl_Lname.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_Lname.Name = "lbl_Lname";
            this.lbl_Lname.Size = new System.Drawing.Size(90, 21);
            this.lbl_Lname.TabIndex = 1;
            this.lbl_Lname.Text = "Last Name";
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Salary.Location = new System.Drawing.Point(66, 218);
            this.lbl_Salary.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(56, 21);
            this.lbl_Salary.TabIndex = 2;
            this.lbl_Salary.Text = "Salary";
            // 
            // lbl_Hourwage
            // 
            this.lbl_Hourwage.AutoSize = true;
            this.lbl_Hourwage.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Hourwage.Location = new System.Drawing.Point(374, 218);
            this.lbl_Hourwage.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_Hourwage.Name = "lbl_Hourwage";
            this.lbl_Hourwage.Size = new System.Drawing.Size(79, 21);
            this.lbl_Hourwage.TabIndex = 3;
            this.lbl_Hourwage.Text = "Hr. Wage";
            // 
            // btn_Staff
            // 
            this.btn_Staff.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Staff.Location = new System.Drawing.Point(167, 86);
            this.btn_Staff.Margin = new System.Windows.Forms.Padding(5);
            this.btn_Staff.Name = "btn_Staff";
            this.btn_Staff.Size = new System.Drawing.Size(181, 37);
            this.btn_Staff.TabIndex = 4;
            this.btn_Staff.Text = "Create Staff Member";
            this.btn_Staff.UseVisualStyleBackColor = true;
            this.btn_Staff.Click += new System.EventHandler(this.btn_Staff_Click);
            // 
            // btn_Ft
            // 
            this.btn_Ft.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ft.Location = new System.Drawing.Point(31, 257);
            this.btn_Ft.Margin = new System.Windows.Forms.Padding(5);
            this.btn_Ft.Name = "btn_Ft";
            this.btn_Ft.Size = new System.Drawing.Size(125, 37);
            this.btn_Ft.TabIndex = 5;
            this.btn_Ft.Text = "Create FT";
            this.btn_Ft.UseVisualStyleBackColor = true;
            this.btn_Ft.Click += new System.EventHandler(this.btn_Ft_Click);
            // 
            // btn_Pt
            // 
            this.btn_Pt.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Pt.Location = new System.Drawing.Point(357, 257);
            this.btn_Pt.Margin = new System.Windows.Forms.Padding(5);
            this.btn_Pt.Name = "btn_Pt";
            this.btn_Pt.Size = new System.Drawing.Size(125, 37);
            this.btn_Pt.TabIndex = 6;
            this.btn_Pt.Text = "Create PT";
            this.btn_Pt.UseVisualStyleBackColor = true;
            this.btn_Pt.Click += new System.EventHandler(this.btn_Pt_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(20, 19);
            this.textBox1.Margin = new System.Windows.Forms.Padding(5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(164, 22);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(333, 19);
            this.textBox2.Margin = new System.Windows.Forms.Padding(5);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(164, 22);
            this.textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(14, 191);
            this.textBox3.Margin = new System.Windows.Forms.Padding(5);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(164, 22);
            this.textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(333, 191);
            this.textBox4.Margin = new System.Windows.Forms.Padding(5);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(164, 22);
            this.textBox4.TabIndex = 10;
            // 
            // lbl_Next
            // 
            this.lbl_Next.AutoSize = true;
            this.lbl_Next.Location = new System.Drawing.Point(454, 312);
            this.lbl_Next.Name = "lbl_Next";
            this.lbl_Next.Size = new System.Drawing.Size(45, 21);
            this.lbl_Next.TabIndex = 11;
            this.lbl_Next.Text = "Next";
            this.lbl_Next.Click += new System.EventHandler(this.lbl_Next_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(511, 342);
            this.Controls.Add(this.lbl_Next);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_Pt);
            this.Controls.Add(this.btn_Ft);
            this.Controls.Add(this.btn_Staff);
            this.Controls.Add(this.lbl_Hourwage);
            this.Controls.Add(this.lbl_Salary);
            this.Controls.Add(this.lbl_Lname);
            this.Controls.Add(this.lbl_Fname);
            this.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Fname;
        private System.Windows.Forms.Label lbl_Lname;
        private System.Windows.Forms.Label lbl_Salary;
        private System.Windows.Forms.Label lbl_Hourwage;
        private System.Windows.Forms.Button btn_Staff;
        private System.Windows.Forms.Button btn_Ft;
        private System.Windows.Forms.Button btn_Pt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lbl_Next;
    }
}

