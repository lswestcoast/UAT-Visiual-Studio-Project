﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Project_2
{
    public partial class Form3 : Form
    {
        int num1, num2;
        string textFile = "test.txt";
        public Form3()
        {
            InitializeComponent();
        }

        void display()
        {
            MessageBox.Show("inside fuction");
            txt_Function.Text = "I'm in a Function";
        }
        double avg(int num1, int num2, int num3)
        {
            return Convert.ToDouble((num1 + num2 + num3) / 3.0);
        }
        int sum(int a, int b, int c)
        {
            int total = a + b + c;
            return total;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("Vaild Int");
            }
            else
            {
                MessageBox.Show("Invaild Int");
            }
            try
            {
                num1 = int.Parse(textBox1.Text);
            }
            catch
            {
                MessageBox.Show("Invaild by Try");
            }
        }

        private void btn_Back1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void btn_4loop_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox2.Text, out num1) && int.TryParse(textBox3.Text, out num2))
            {
                for (int i = num1; i < num2; i++)
                {
                    MessageBox.Show(" i = " + i);
                }
            }
        }

        private void btn_While_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox2.Text, out num1) && int.TryParse(textBox3.Text, out num2))
            {
                int i = num1;
                while (i < num2)
                {
                    MessageBox.Show("While i = " + i);
                    i++;
                }
            }
        }

        private void btn_doloop_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox2.Text, out num1) && int.TryParse(textBox3.Text, out num2))
            {
                int i = num1;
                do
                {
                    MessageBox.Show("do i = " + i);
                    i++;
                } while (i < num2);
            }
        }

        private void btn_R2F_Click(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader(textFile))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    line = line.Trim();
                    MessageBox.Show(line);
                }
            }
        }

        private void btn_W2F_Click(object sender, EventArgs e)
        {
            using (StreamWriter writer = File.AppendText(textFile))
            {
                writer.Write(textBox4.Text + Environment.NewLine);
            }
        }

        private void btn_Dialog_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files (*.txt) |*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.ShowDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var filePath = openFileDialog1.FileName;
                var fileStream = openFileDialog1.OpenFile();

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    var fileContent = reader.ReadToEnd();
                    textBox1.Text = fileContent;
                    MessageBox.Show(fileContent);
                }
            }
        }

        private void btn_Function_Click(object sender, EventArgs e)
        {
            display();
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void btn_Average_Click(object sender, EventArgs e)
        {
            double av = avg(1, 2, 1);
            txt_Function.Text = av.ToString();
        }

        private void btn_Sum_Click(object sender, EventArgs e)
        {
            int addition = sum(1, 2, 3);
            MessageBox.Show("sum = " + addition);
        }
    }
}
