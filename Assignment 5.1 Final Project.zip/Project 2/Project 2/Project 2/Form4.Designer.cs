﻿namespace Project_2
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            groupBox2 = new GroupBox();
            btn_Refresh = new Button();
            textBox1 = new TextBox();
            progressBar1 = new ProgressBar();
            btn_Enter = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox3 = new GroupBox();
            btn_Selection = new Button();
            listBox2 = new ListBox();
            listBox1 = new ListBox();
            groupBox4 = new GroupBox();
            teamBox = new TextBox();
            btn_Clear = new Button();
            btn_Remove = new Button();
            btm_Count = new Button();
            btn_Add = new Button();
            footballTeams = new ListBox();
            btn_Back1 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(200, 237);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // button1
            // 
            button1.Location = new Point(23, 33);
            button1.Name = "button1";
            button1.Size = new Size(151, 23);
            button1.TabIndex = 1;
            button1.Text = "NFL Teams";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(24, 81);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(150, 150);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btn_Refresh);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Controls.Add(progressBar1);
            groupBox2.Controls.Add(btn_Enter);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Location = new Point(218, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(406, 237);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "groupBox2";
            // 
            // btn_Refresh
            // 
            btn_Refresh.Location = new Point(6, 147);
            btn_Refresh.Name = "btn_Refresh";
            btn_Refresh.Size = new Size(150, 23);
            btn_Refresh.TabIndex = 7;
            btn_Refresh.Text = "Refresh";
            btn_Refresh.UseVisualStyleBackColor = true;
            btn_Refresh.Click += btn_Refresh_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(196, 59);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(204, 23);
            textBox1.TabIndex = 6;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(6, 176);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(394, 23);
            progressBar1.TabIndex = 5;
            // 
            // btn_Enter
            // 
            btn_Enter.Location = new Point(250, 147);
            btn_Enter.Name = "btn_Enter";
            btn_Enter.Size = new Size(150, 23);
            btn_Enter.TabIndex = 4;
            btn_Enter.Text = "Enter";
            btn_Enter.UseVisualStyleBackColor = true;
            btn_Enter.Click += btn_Enter_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(192, 213);
            label4.Name = "label4";
            label4.Size = new Size(23, 15);
            label4.TabIndex = 3;
            label4.Text = "0%";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(203, 109);
            label3.Name = "label3";
            label3.Size = new Size(0, 15);
            label3.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(11, 61);
            label2.Name = "label2";
            label2.Size = new Size(118, 21);
            label2.TabIndex = 1;
            label2.Text = "Enter the 1st #";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(11, 19);
            label1.Name = "label1";
            label1.Size = new Size(196, 26);
            label1.TabIndex = 0;
            label1.Text = "Input five number";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btn_Selection);
            groupBox3.Controls.Add(listBox2);
            groupBox3.Controls.Add(listBox1);
            groupBox3.Location = new Point(12, 255);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(200, 237);
            groupBox3.TabIndex = 1;
            groupBox3.TabStop = false;
            groupBox3.Text = "groupBox3";
            // 
            // btn_Selection
            // 
            btn_Selection.Location = new Point(58, 192);
            btn_Selection.Name = "btn_Selection";
            btn_Selection.Size = new Size(75, 23);
            btn_Selection.TabIndex = 2;
            btn_Selection.Text = "Selection";
            btn_Selection.UseVisualStyleBackColor = true;
            btn_Selection.Click += btn_Selection_Click;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(23, 107);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(150, 79);
            listBox2.TabIndex = 1;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(23, 22);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(150, 79);
            listBox1.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(teamBox);
            groupBox4.Controls.Add(btn_Clear);
            groupBox4.Controls.Add(btn_Remove);
            groupBox4.Controls.Add(btm_Count);
            groupBox4.Controls.Add(btn_Add);
            groupBox4.Controls.Add(footballTeams);
            groupBox4.Location = new Point(218, 255);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(405, 237);
            groupBox4.TabIndex = 1;
            groupBox4.TabStop = false;
            groupBox4.Text = "groupBox4";
            // 
            // teamBox
            // 
            teamBox.Location = new Point(11, 51);
            teamBox.Name = "teamBox";
            teamBox.Size = new Size(142, 23);
            teamBox.TabIndex = 5;
            teamBox.TextAlign = HorizontalAlignment.Center;
            // 
            // btn_Clear
            // 
            btn_Clear.Location = new Point(11, 200);
            btn_Clear.Name = "btn_Clear";
            btn_Clear.Size = new Size(145, 23);
            btn_Clear.TabIndex = 4;
            btn_Clear.Text = "Clear";
            btn_Clear.UseVisualStyleBackColor = true;
            // 
            // btn_Remove
            // 
            btn_Remove.Location = new Point(11, 171);
            btn_Remove.Name = "btn_Remove";
            btn_Remove.Size = new Size(145, 23);
            btn_Remove.TabIndex = 3;
            btn_Remove.Text = "Remove";
            btn_Remove.UseVisualStyleBackColor = true;
            btn_Remove.Click += btn_Remove_Click;
            // 
            // btm_Count
            // 
            btm_Count.Location = new Point(11, 142);
            btm_Count.Name = "btm_Count";
            btm_Count.Size = new Size(145, 23);
            btm_Count.TabIndex = 2;
            btm_Count.Text = "Count";
            btm_Count.UseVisualStyleBackColor = true;
            btm_Count.Click += btm_Count_Click;
            // 
            // btn_Add
            // 
            btn_Add.Location = new Point(11, 80);
            btn_Add.Name = "btn_Add";
            btn_Add.Size = new Size(142, 23);
            btn_Add.TabIndex = 1;
            btn_Add.Text = "Add";
            btn_Add.UseVisualStyleBackColor = true;
            btn_Add.Click += btn_Add_Click;
            // 
            // footballTeams
            // 
            footballTeams.FormattingEnabled = true;
            footballTeams.ItemHeight = 15;
            footballTeams.Items.AddRange(new object[] { "Arizona Cardinals", "Atlanta Falcons", "Baltimore Ravens", "Buffalo Bills", "Carolina Panthers", "Chicago Bears", "Cincinnati Bengals", "Cleveland Browns", "Dallas Cowboys", "Denver Broncos", "Detroit Lions", "Green Bay Packers", "Houston Texans", "Indianapolis Colts", "Jacksonville Jaguars", "Kansas City Chiefs", "Las Vegas Raiders", "Los Angeles Chargers", "Los Angeles Rams", "Miami Dolphins", "Minnesota Vikings", "New England Patriots", "New Orleans Saints", "New York Giants", "New York Jets", "Philadelphia Eagles", "Pittsburgh Steelers", "San Francisco 49ers", "Seattle Seahawks", "Tampa Bay Buccaneers", "Tennessee Titans", "Washington Commanders" });
            footballTeams.Location = new Point(250, 22);
            footballTeams.Name = "footballTeams";
            footballTeams.SelectionMode = SelectionMode.MultiSimple;
            footballTeams.Size = new Size(148, 199);
            footballTeams.TabIndex = 0;
            // 
            // btn_Back1
            // 
            btn_Back1.Location = new Point(12, 498);
            btn_Back1.Name = "btn_Back1";
            btn_Back1.Size = new Size(75, 23);
            btn_Back1.TabIndex = 2;
            btn_Back1.Text = "Back";
            btn_Back1.UseVisualStyleBackColor = true;
            btn_Back1.Click += btn_Back1_Click;
            // 
            // Form4
            // 
            AcceptButton = btn_Enter;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(635, 540);
            Controls.Add(btn_Back1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox3);
            Controls.Add(groupBox4);
            Controls.Add(groupBox1);
            Name = "Form4";
            Text = "Form4";
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private Button btn_Back1;
        private Button button1;
        private PictureBox pictureBox1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox1;
        private ProgressBar progressBar1;
        private Button btn_Enter;
        private Button btn_Refresh;
        private ListBox listBox1;
        private Button btn_Selection;
        private ListBox listBox2;
        private ListBox footballTeams;
        private Button btn_Clear;
        private Button btn_Remove;
        private Button btm_Count;
        private Button btn_Add;
        private TextBox teamBox;
    }
}