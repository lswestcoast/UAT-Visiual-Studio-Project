﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_6._1_Final_Project_v3
{
    public partial class Form1 : Form
    {
        class employee
        {
            private string fname;
            private string lname;

            public employee(string fn, string ln)
            {
                if (fn.Length == 0)
                {
                    MessageBox.Show("invalid fname, name set to John");
                    fname = "jane";
                }
                else
                    fname = fn;

                if (ln.Length == 0)
                {
                    MessageBox.Show("invalid lname, name set to Smith");
                    lname = "Doe";
                }
                else
                    lname = ln;
            }
            public string Fname
            {
                get { return fname; }
                set { fname = value; }
            }
            public void display()
            {
                MessageBox.Show("employee name = " + fname + " " + lname);
            }
        }

        class Ft : employee
        {
            private double salary;

            public Ft(string fn, string ln, double sal) : base(fn, ln)
            {
                if (sal < 20000)
                {
                    salary = 25000;
                    MessageBox.Show("Too low - bumped salary to 25000");
                }
                else
                    salary = sal;
            }

            public void display()
            {
                base.display();
                MessageBox.Show("Salary = " + salary.ToString());
            }
        }
        class PT : employee
        {
            private double wageRate;

            public PT(string fn, string ln, double wage) : base(fn, ln)
            {
                if (wage < 17.00)
                {
                    MessageBox.Show("too low - updated to 22.00");
                    wageRate = 22;
                }
                else
                {
                    wageRate = wage;
                }
            }

            public void display()
            {
                base.display();
                MessageBox.Show("wage = " + wageRate.ToString());
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Staff_Click(object sender, EventArgs e)
        {
            employee e1 = new employee(textBox1.Text, textBox2.Text);
            e1.display();
        }

        private void btn_Ft_Click(object sender, EventArgs e)
        {
            double sal = double.Parse(textBox3.Text);
            Ft ft1 = new Ft(textBox1.Text, textBox2.Text, sal);
            ft1.display();
        }

        private void btn_Pt_Click(object sender, EventArgs e)
        {
            double wage = double.Parse(textBox4.Text);
            PT pt1 = new PT(textBox1.Text, textBox2.Text, wage);
            pt1.display();
        }

        private void lbl_Next_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }
    }
}
