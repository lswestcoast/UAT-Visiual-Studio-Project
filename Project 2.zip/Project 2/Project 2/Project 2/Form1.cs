namespace Project_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            progressBar1.Value = 0;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtName.Text) && !lstNames.Items.Contains(txtName.Text))
                lstNames.Items.Add(txtName.Text);
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lbl_HelloWorld.Text = "Hello World";
            progressBar1.Value += 25;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Month");
            comboBox1.Items.Add("Day");

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            if (comboBox1.SelectedItem == "Month")
            {
                comboBox2.Items.Add("January");
                comboBox2.Items.Add("Febuary");
                comboBox2.Items.Add("March");
                comboBox2.Items.Add("April");
                comboBox2.Items.Add("May");
                comboBox2.Items.Add("June");
                comboBox2.Items.Add("July");
                comboBox2.Items.Add("August");
                comboBox2.Items.Add("September");
                comboBox2.Items.Add("October");
                comboBox2.Items.Add("November");
                comboBox2.Items.Add("December");
            }
            else if (comboBox1.SelectedItem == "Day")
            {
                comboBox2.Items.Add("Monday");
                comboBox2.Items.Add("Tuesday");
                comboBox2.Items.Add("Wedesday");
                comboBox2.Items.Add("Thursday");
                comboBox2.Items.Add("Firday");
                comboBox2.Items.Add("Saturday");
                comboBox2.Items.Add("Sunday");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Who Da");
        }
    }
}