﻿namespace Project_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lstNames = new ListBox();
            txtName = new TextBox();
            btnAdd = new Button();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            lbl_HelloWorld = new Label();
            btn_ClickMe = new Button();
            groupBox3 = new GroupBox();
            progressBar1 = new ProgressBar();
            groupBox4 = new GroupBox();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            groupBox5 = new GroupBox();
            checkBox1 = new CheckBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 56);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 0;
            label1.Text = "Names";
            // 
            // lstNames
            // 
            lstNames.FormattingEnabled = true;
            lstNames.ItemHeight = 15;
            lstNames.Location = new Point(28, 69);
            lstNames.Margin = new Padding(3, 2, 3, 2);
            lstNames.Name = "lstNames";
            lstNames.Size = new Size(135, 94);
            lstNames.TabIndex = 1;
            // 
            // txtName
            // 
            txtName.Location = new Point(169, 69);
            txtName.Margin = new Padding(3, 2, 3, 2);
            txtName.Name = "txtName";
            txtName.Size = new Size(102, 23);
            txtName.TabIndex = 2;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(169, 108);
            btnAdd.Margin = new Padding(3, 2, 3, 2);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(102, 55);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "Add Name";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lstNames);
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtName);
            groupBox1.Location = new Point(36, 39);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(300, 300);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lbl_HelloWorld);
            groupBox2.Controls.Add(btn_ClickMe);
            groupBox2.Location = new Point(406, 39);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(300, 300);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            groupBox2.Text = "groupBox2";
            // 
            // lbl_HelloWorld
            // 
            lbl_HelloWorld.AutoSize = true;
            lbl_HelloWorld.Font = new Font("Times New Roman", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lbl_HelloWorld.ForeColor = Color.Black;
            lbl_HelloWorld.Location = new Point(28, 213);
            lbl_HelloWorld.Name = "lbl_HelloWorld";
            lbl_HelloWorld.Size = new Size(0, 54);
            lbl_HelloWorld.TabIndex = 1;
            // 
            // btn_ClickMe
            // 
            btn_ClickMe.FlatAppearance.MouseDownBackColor = Color.Green;
            btn_ClickMe.FlatAppearance.MouseOverBackColor = Color.FromArgb(64, 64, 64);
            btn_ClickMe.FlatStyle = FlatStyle.Flat;
            btn_ClickMe.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point);
            btn_ClickMe.ForeColor = Color.Black;
            btn_ClickMe.Location = new Point(74, 108);
            btn_ClickMe.Name = "btn_ClickMe";
            btn_ClickMe.Size = new Size(149, 81);
            btn_ClickMe.TabIndex = 0;
            btn_ClickMe.Text = "Click Me";
            btn_ClickMe.UseVisualStyleBackColor = true;
            btn_ClickMe.Click += button1_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(progressBar1);
            groupBox3.Location = new Point(778, 39);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(300, 300);
            groupBox3.TabIndex = 6;
            groupBox3.TabStop = false;
            groupBox3.Text = "groupBox3";
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(69, 108);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(146, 79);
            progressBar1.Style = ProgressBarStyle.Marquee;
            progressBar1.TabIndex = 0;
            progressBar1.Click += progressBar1_Click;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(comboBox2);
            groupBox4.Controls.Add(comboBox1);
            groupBox4.Location = new Point(219, 420);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(300, 300);
            groupBox4.TabIndex = 6;
            groupBox4.TabStop = false;
            groupBox4.Text = "groupBox4";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(94, 177);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 1;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Month", "Day" });
            comboBox1.Location = new Point(94, 96);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 0;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(checkBox1);
            groupBox5.Location = new Point(609, 420);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(300, 300);
            groupBox5.TabIndex = 6;
            groupBox5.TabStop = false;
            groupBox5.Text = "groupBox5";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = SystemColors.ActiveCaptionText;
            checkBox1.Font = new Font("Times New Roman", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            checkBox1.ForeColor = Color.FromArgb(192, 192, 0);
            checkBox1.Location = new Point(44, 139);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(217, 32);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "New Orlean Saints";
            checkBox1.TextAlign = ContentAlignment.MiddleCenter;
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1212, 860);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Names";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private ListBox lstNames;
        private TextBox txtName;
        private Button btnAdd;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Button btn_ClickMe;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private GroupBox groupBox5;
        private ProgressBar progressBar1;
        private Label lbl_HelloWorld;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private CheckBox checkBox1;
    }
}