﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2
{
    public partial class Form3 : Form
    {
        int num1;
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out num1))
            {
                MessageBox.Show("Vaild Int");
            }
            else
            {
                MessageBox.Show("Invaild Int");
            }
            try
            {
                num1 = int.Parse(textBox1.Text);
            }
            catch 
            {
                MessageBox.Show("Invaild by Try");      
            }
        }

        private void btn_Back1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
