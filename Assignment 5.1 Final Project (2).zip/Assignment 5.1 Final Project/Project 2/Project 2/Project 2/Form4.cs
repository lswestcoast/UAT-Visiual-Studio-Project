﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic;

namespace Project_2
{
    public partial class Form4 : Form
    {
        List<string> li = new List<string>() { "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X" };
        public Form4()
        {
            InitializeComponent();

            listBox1.Items.Add("Sun");
            listBox1.Items.Add("Mon");
            listBox1.Items.Add("Tues");
            listBox1.Items.Add("Wed");
            listBox1.Items.Add("Thur");
            listBox1.Items.Add("Fir");
            listBox1.Items.Add("Sat");
            listBox1.SelectionMode = SelectionMode.MultiSimple;
            listBox2.DataSource = li;

        }
        double[] number = new double[5];
        int i = 0;
        double[] new_order = new double[5];

        private void btn_Back1_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }
        int intImgNum = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = imageList1.Images[intImgNum];
            if (intImgNum == imageList1.Images.Count - 1)
            {
                intImgNum = 0;
            }
            else
            {
                intImgNum++;
            }

        }

        private void btn_Enter_Click(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
            {
                switch (i)
                {
                    case 0:
                        label2.Text = "Enter the 2nd #";
                        break;
                    case 1:
                        label2.Text = "Enter the 3rd #";
                        break;
                    case 2:
                        label2.Text = "Enter the 4th #";
                        break;
                    case 3:
                        label2.Text = "Enter the 5th #";
                        break;
                    default:
                        label2.Text = "Hit Enter or Click the button below!!!";
                        break;
                }
                number[i] = double.Parse(textBox1.Text);
                i++;
                label4.Text = progressBar1.Value + "%";
                progressBar1.Value = progressBar1.Value + 20;
                textBox1.Text = "";

                if (i == 5)
                {
                    textBox1.Visible = false;
                }
            }
            else
            {
                int k = 0;
                label3.Text = "Answer is = ";
                for (int j = 4; j >= 0; j--)
                {
                    new_order[k] = number[j];
                    label3.Text = label3.Text + "," + new_order[k];
                    k++;
                }
            }
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Form4 NewForm = new Form4();
            NewForm.Show();
            this.Dispose(false);
        }
        private void Form4_Load(object sender, EventArgs e)
        {
           
        }

        private void btn_Selection_Click(object sender, EventArgs e)
        {
            foreach (var item in listBox1.SelectedItems)
            {
                MessageBox.Show(item.ToString());
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            footballTeams.Items.Add(teamBox.Text);
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            footballTeams.Items.Remove(footballTeams.SelectedItem);
        }

        private void btm_Count_Click(object sender, EventArgs e)
        {
            MessageBox.Show(footballTeams.Items.Count.ToString());
        }
    }
}
